import express from "express"
import {
  loginEmployee,
  getMe,
  updatePassword,
  getAssignedBookings,
  getAssignedOrders,
  updateBookingStatus,
  updateOrderStatus,
  getDashboardData,
} from "../controllers/employee.controller.js"
import { employeeProtect, authorizeEmployee } from "../middleware/auth.middleware.js"

const router = express.Router()

router.post("/login", loginEmployee)
router.get("/me", employeeProtect, getMe)
router.put("/update-password", employeeProtect, updatePassword)
router.get("/dashboard", employeeProtect, getDashboardData)
router.get("/bookings", employeeProtect, getAssignedBookings)
router.get("/orders", employeeProtect, authorizeEmployee("product"), getAssignedOrders)
router.put("/bookings/:id/status", employeeProtect, updateBookingStatus)
router.put("/orders/:id/status", employeeProtect, authorizeEmployee("product"), updateOrderStatus)

export default router

