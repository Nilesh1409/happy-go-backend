import jwt from "jsonwebtoken";
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import User from "../models/user.model.js";
import Employee from "../models/employee.model.js";

export const protect = asyncHandler(async (req, res, next) => {
  let token;

  // Log basic request details: Timestamp, HTTP method, endpoint, and IP address
  const requestTime = new Date();
  // console.log(`API Request received at: ${requestTime.toISOString()}`);
  // console.log(`Request Type: ${req.method}`);
  // console.log(`Endpoint: ${req.originalUrl}`);
  // console.log(`Requester IP: ${req.ip}`);

  // Check if token exists in headers
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    token = req.headers.authorization.split(" ")[1];
  }
  console.log("🚀 ~ protect ~ token:", token, req.headers);

  // Check if token exists
  if (!token) {
    return next(new ApiError("Not authorized to access this route", 401));
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Check if user exists
    const user = await User.findById(decoded.id).select("-password");
    if (!user) {
      return next(new ApiError("User not found", 404));
    }

    // Add user to request
    req.user = user;
    next();
  } catch (error) {
    return next(new ApiError("Not authorized to access this route", 401));
  }
});

export const adminProtect = asyncHandler(async (req, res, next) => {
  let token;

  // Check if token exists in headers
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    token = req.headers.authorization.split(" ")[1];
  }

  // Check if token exists
  if (!token) {
    return next(new ApiError("Not authorized to access this route", 401));
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Check if admin exists
    const admin = await User.findById(decoded.id).select("-password");
    if (!admin || admin.role !== "admin") {
      return next(new ApiError("Not authorized as admin", 403));
    }

    // Add admin to request
    req.user = admin;
    next();
  } catch (error) {
    return next(new ApiError("Not authorized to access this route", 401));
  }
});

export const employeeProtect = asyncHandler(async (req, res, next) => {
  let token;

  // Check if token exists in headers
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    token = req.headers.authorization.split(" ")[1];
  }

  // Check if token exists
  if (!token) {
    return next(new ApiError("Not authorized to access this route", 401));
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Check if employee exists
    const employee = await Employee.findById(decoded.id).select("-password");
    if (!employee) {
      return next(new ApiError("Employee not found", 404));
    }

    // Add employee to request
    req.employee = employee;
    next();
  } catch (error) {
    return next(new ApiError("Not authorized to access this route", 401));
  }
});

export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(
        new ApiError(
          `User role ${req.user.role} is not authorized to access this route`,
          403
        )
      );
    }
    next();
  };
};

export const authorizeEmployee = (moduleType) => {
  return asyncHandler(async (req, res, next) => {
    // Check if employee has access to this module
    if (!req.employee.assignedModules.includes(moduleType)) {
      return next(
        new ApiError(
          `Employee is not authorized to access ${moduleType} module`,
          403
        )
      );
    }
    next();
  });
};
