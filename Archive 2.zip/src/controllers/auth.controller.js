import User from "../models/user.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { generateToken } from "../utils/generateToken.js";
import { sendEmail } from "../utils/sendEmail.js";
import { sendSMS } from "../utils/sendSMS.js";
import crypto from "crypto";

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
export const registerUser = asyncHandler(async (req, res) => {
  const { name, email, mobile } = req.body;

  // Check if user already exists
  const userExists = await User.findOne({ $or: [{ email }, { mobile }] });

  if (userExists) {
    throw new ApiError("User already exists", 400);
  }

  // Create user
  const user = await User.create({
    name,
    email,
    mobile,
  });

  // Generate email verification token
  const emailVerificationToken = user.generateEmailVerificationToken();
  await user.save();

  // Create verification URL
  const verificationURL = `${process.env.FRONTEND_URL}/verify-email/${emailVerificationToken}`;

  // Send email
  const message = `
    <h1>Email Verification</h1>
    <p>Please click on the link below to verify your email:</p>
    <a href="${verificationURL}" target="_blank">Verify Email</a>
  `;

  await sendEmail({
    email: user.email,
    subject: "Email Verification",
    message,
  });

  res.status(201).json({
    success: true,
    message: "User registered successfully. Please verify your email.",
    data: {
      _id: user._id,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      isEmailVerified: user.isEmailVerified,
      isMobileVerified: user.isMobileVerified,
    },
  });
});

// @desc    Verify email
// @route   GET /api/auth/verify-email/:token
// @access  Public
export const verifyEmail = asyncHandler(async (req, res) => {
  // Get hashed token
  const emailVerificationToken = crypto
    .createHash("sha256")
    .update(req.params.token)
    .digest("hex");

  const user = await User.findOne({
    emailVerificationToken,
    emailVerificationExpire: { $gt: Date.now() },
  });

  if (!user) {
    throw new ApiError("Invalid or expired token", 400);
  }

  // Set email as verified
  user.isEmailVerified = true;
  user.emailVerificationToken = undefined;
  user.emailVerificationExpire = undefined;
  await user.save();

  res.status(200).json({
    success: true,
    message: "Email verified successfully",
  });
});

// @desc    Send OTP for mobile verification
// @route   POST /api/auth/send-mobile-otp
// @access  Public
export const sendMobileOTP = asyncHandler(async (req, res) => {
  const { mobile } = req.body;

  // Check if user exists
  const user = await User.findOne({ mobile });

  if (!user) {
    throw new ApiError("User not found", 404);
  }

  // Generate OTP
  const otp = user.generateMobileVerificationOTP();
  console.log("🚀 ~ sendMobileOTP ~ otp:", otp);
  await user.save();

  // Send OTP via SMS
  // await sendSMS({
  //   phone: user.mobile,
  //   message: `Your OTP for HappyGo is: ${otp}. Valid for 10 minutes.`,
  // });

  res.status(200).json({
    success: true,
    message: "OTP sent successfully",
  });
});

// @desc    Verify mobile OTP
// @route   POST /api/auth/verify-mobile-otp
// @access  Public
export const verifyMobileOTP = asyncHandler(async (req, res) => {
  const { mobile, otp } = req.body;

  // Check if user exists
  const user = await User.findOne({
    mobile,
    mobileVerificationOTP: otp,
    mobileVerificationExpire: { $gt: Date.now() },
  });

  if (!user) {
    throw new ApiError("Invalid or expired OTP", 400);
  }

  // Set mobile as verified
  user.isMobileVerified = true;
  user.mobileVerificationOTP = undefined;
  user.mobileVerificationExpire = undefined;
  await user.save();

  // Generate token
  const token = generateToken(user._id);

  res.status(200).json({
    success: true,
    message: "Mobile verified successfully",
    token,
    data: {
      _id: user._id,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      isEmailVerified: user.isEmailVerified,
      isMobileVerified: user.isMobileVerified,
      walletBalance: user.walletBalance,
      referralCode: user.referralCode,
      role: user.role,
    },
  });
});

// @desc    Login user with mobile OTP
// @route   POST /api/auth/login
// @access  Public
export const loginUser = asyncHandler(async (req, res) => {
  const { mobile } = req.body;
  console.log("🚀 ~ loginUser ~ mobile:", mobile);

  // Check if user exists
  const user = await User.findOne({ mobile });

  if (!user) {
    throw new ApiError("User not found", 404);
  }

  // Generate OTP
  const otp = user.generateMobileVerificationOTP();
  await user.save();

  // Send OTP via SMS
  // await sendSMS({
  //   phone: user.mobile,
  //   message: `Your OTP for HappyGo login is: ${otp}. Valid for 10 minutes.`,
  // });

  res.status(200).json({
    success: true,
    message: "OTP sent successfully",
  });
});

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
export const getMe = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id);

  res.status(200).json({
    success: true,
    data: {
      _id: user._id,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      isEmailVerified: user.isEmailVerified,
      isMobileVerified: user.isMobileVerified,
      walletBalance: user.walletBalance,
      referralCode: user.referralCode,
    },
  });
});
