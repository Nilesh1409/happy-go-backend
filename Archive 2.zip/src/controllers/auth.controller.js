import User from "../models/user.model.js";
import Employee from "../models/employee.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { generateToken } from "../utils/generateToken.js";
import { sendEmail } from "../utils/sendEmail.js";
import crypto from "crypto";
import Referral from "../models/referral.model.js";

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
// @desc    Register a new user and send OTP
// @route   POST /api/auth/register
// @access  Public
export const registerUser = asyncHandler(async (req, res) => {
  const { name, email, mobile, referralCode } = req.body;
  console.log(
    "🚀 ~ registerUser ~ name, email, mobile, referralCode:",
    name,
    email,
    mobile,
    referralCode
  );

  // Validation
  if (!name || !email || !mobile) {
    throw new ApiError("Please provide all required fields", 400);
  }

  if (!/^[0-9]{10}$/.test(mobile)) {
    throw new ApiError("Please provide a valid 10-digit mobile number", 400);
  }

  if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
    throw new ApiError("Please provide a valid email address", 400);
  }

  // Check if user already exists
  const userExists = await User.findOne({ $or: [{ email }, { mobile }] });
  console.log("🚀 ~ registerUser ~ userExists:", userExists);

  if (userExists) {
    throw new ApiError("User with this email or mobile already exists", 400);
  }

  let referrer = null;
  let referralRecord = null;

  // Validate referral code if provided
  if (referralCode && referralCode.trim()) {
    referrer = await User.findOne({
      referralCode: referralCode.trim().toUpperCase(),
    });
    if (!referrer) {
      throw new ApiError("Invalid referral code", 400);
    }
  }

  // Create user
  const user = await User.create({
    name: name.trim(),
    email: email.toLowerCase().trim(),
    mobile: mobile.trim(),
    referredBy: referrer ? referrer._id : null,
  });

  // Create referral record if referral code was used
  if (referrer) {
    referralRecord = await Referral.create({
      referrer: referrer._id,
      referred: user._id,
      referralCode: referralCode.trim().toUpperCase(),
      status: "pending",
      reward: 500, // ₹500 reward
      expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
    });
  }

  // Generate email verification token
  const emailVerificationToken = user.generateEmailVerificationToken();

  // Generate mobile OTP immediately
  const mobileOTP = user.generateMobileVerificationOTP();
  await user.save();

  // Create verification URL
  const verificationURL = `${process.env.FRONTEND_URL}/verify-email/${emailVerificationToken}`;

  // Enhanced email message
  const message = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
      <div style="text-align: center; margin-bottom: 30px;">
        <div style="width: 60px; height: 60px; background-color: #F47B20; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 15px;">
          <span style="color: white; font-weight: bold; font-size: 24px;">HG</span>
        </div>
        <h1 style="color: #F47B20; margin: 0; font-size: 28px;">Welcome to Happy Go!</h1>
        <p style="color: #666666; margin: 10px 0 0 0;">Anywhere Everytime</p>
      </div>

      <div style="background-color: #f8f9fa; border-radius: 8px; padding: 20px; margin: 20px 0;">
        <h2 style="color: #333333; margin: 0 0 15px 0; font-size: 20px;">Hi ${
          user.name
        }! 👋</h2>
        <p style="color: #666666; margin: 0 0 20px 0; line-height: 1.5;">
          Your account has been created successfully! We've sent an OTP to your mobile number for verification.
        </p>
        
        <div style="background-color: #E3F2FD; border-radius: 6px; padding: 15px; margin: 15px 0; text-align: center;">
          <p style="color: #1976D2; margin: 0 0 10px 0; font-weight: bold;">Your Mobile Verification OTP:</p>
          <div style="background-color: white; border: 2px solid #1976D2; border-radius: 6px; padding: 10px; display: inline-block;">
            <span style="font-family: monospace; font-size: 24px; font-weight: bold; letter-spacing: 4px; color: #1976D2;">${mobileOTP}</span>
          </div>
          <p style="color: #1565C0; margin: 10px 0 0 0; font-size: 12px;">This OTP expires in 10 minutes</p>
        </div>

        <div style="text-align: center; margin: 25px 0;">
          <a href="${verificationURL}" 
             style="background-color: #F47B20; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
            Verify Email Address
          </a>
        </div>
      </div>

      ${
        referralRecord
          ? `
        <div style="background-color: #FFF3E0; border: 2px solid #FFB74D; border-radius: 8px; padding: 20px; margin: 20px 0;">
          <div style="text-align: center;">
            <h3 style="color: #F47B20; margin: 0 0 10px 0; font-size: 18px;">🎉 Referral Applied Successfully!</h3>
            <p style="color: #E65100; margin: 0 0 10px 0; font-weight: bold;">
              You've been referred by ${referrer.name}
            </p>
            <div style="background-color: #FFCC02; color: #333; padding: 10px; border-radius: 6px; font-weight: bold;">
              Earn ₹500 when you complete your first booking!
            </div>
          </div>
        </div>
      `
          : ""
      }

      <div style="background-color: #E3F2FD; border-radius: 8px; padding: 20px; margin: 20px 0;">
        <h3 style="color: #1976D2; margin: 0 0 10px 0; font-size: 16px;">Your Referral Code</h3>
        <div style="background-color: white; border: 2px dashed #1976D2; border-radius: 6px; padding: 15px; text-align: center;">
          <code style="font-size: 20px; font-weight: bold; color: #1976D2; letter-spacing: 2px;">
            ${user.referralCode}
          </code>
        </div>
        <p style="color: #1565C0; margin: 10px 0 0 0; font-size: 14px; text-align: center;">
          Share this code with friends and earn ₹100 for each successful referral!
        </p>
      </div>

      <div style="border-top: 1px solid #eeeeee; padding-top: 20px; margin-top: 30px; text-align: center;">
        <p style="color: #999999; font-size: 12px; margin: 0;">
          If you didn't create this account, please ignore this email.
        </p>
        <p style="color: #999999; font-size: 12px; margin: 5px 0 0 0;">
          Need help? Contact us at support@happygo.com or call +91 90080-22800
        </p>
      </div>
    </div>
  `;

  // Send email
  await sendEmail({
    email: user.email,
    subject: "Welcome to Happy Go - Verify Your Account",
    message,
  });

  console.log("🚀 ~ registerUser ~ mobileOTP:", mobileOTP);

  // Optional: Send SMS OTP (uncomment when SMS service is ready)
  // await sendSMS({
  //   phone: mobile,
  //   message: `Welcome to Happy Go! Your verification OTP is: ${mobileOTP}. Valid for 10 minutes.`,
  // });

  res.status(201).json({
    success: true,
    message:
      "Registration successful! Please verify the OTP sent to your mobile number.",
    data: {
      _id: user._id,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      isEmailVerified: user.isEmailVerified,
      isMobileVerified: user.isMobileVerified,
      referralCode: user.referralCode,
      referredBy: user.referredBy,
      referralApplied: !!referralRecord,
      referralReward: referralRecord ? referralRecord.reward : 0,
      referrerName: referrer ? referrer.name : null,
      otpSent: true, // Indicate OTP was sent
    },
  });
});

// Keep your existing verifyMobileOTP method as is - it already issues JWT tokens

// @desc    Verify email
// @route   GET /api/auth/verify-email/:token
// @access  Public
export const verifyEmail = asyncHandler(async (req, res) => {
  // Get hashed token
  const emailVerificationToken = crypto
    .createHash("sha256")
    .update(req.params.token)
    .digest("hex");

  const user = await User.findOne({
    emailVerificationToken,
    emailVerificationExpire: { $gt: Date.now() },
  });

  if (!user) {
    throw new ApiError("Invalid or expired token", 400);
  }

  // Set email as verified
  user.isEmailVerified = true;
  user.emailVerificationToken = undefined;
  user.emailVerificationExpire = undefined;
  await user.save();

  res.status(200).json({
    success: true,
    message: "Email verified successfully",
  });
});

// @desc    Send OTP for mobile verification
// @route   POST /api/auth/send-mobile-otp
// @access  Public
export const sendMobileOTP = asyncHandler(async (req, res) => {
  const { mobile } = req.body;

  // Check if user exists - check both User and Employee models
  const foundUser = await User.findOne({ mobile });
  let foundEmployee = null;
  let entityType = "user";

  if (!foundUser) {
    // If not found in User model, check Employee model
    foundEmployee = await Employee.findOne({ mobile });
    if (foundEmployee) {
      entityType = "employee";
    } else {
      throw new ApiError("User not found", 404);
    }
  }

  // Generate OTP for the found entity (user or employee)
  let otp;

  if (entityType === "user") {
    otp = foundUser.generateMobileVerificationOTP();
    await foundUser.save();
  } else {
    // If the entity is an employee, generate OTP for them
    otp = await generateEmployeeOTP(foundEmployee);
  }

  const message = `
  <div style="max-width: 400px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; padding: 30px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
    <h2 style="margin: 0 0 20px; color: #333333; font-size: 20px;">Your Login Code</h2>
    
    <div style="background-color: #f5f5f5; border-radius: 6px; padding: 15px; margin: 20px 0;">
      <span style="font-family: monospace; font-size: 24px; font-weight: bold; letter-spacing: 4px; color: #333333;">${otp}</span>
    </div>
    
    <p style="margin: 0; color: #666666; font-size: 14px;">This code expires in 10 minutes.</p>
  </div>
`;

  let userData = entityType === "user" ? foundUser : foundEmployee;
  await sendEmail({
    email: userData.email,
    subject: "Email Verification",
    message,
  });

  console.log("🚀 ~ sendMobileOTP ~ otp:", otp);

  // Send OTP via SMS
  // await sendSMS({
  //   phone: mobile,
  //   message: `Your OTP for HappyGo is: ${otp}. Valid for 10 minutes.`,
  // });

  res.status(200).json({
    success: true,
    message: "OTP sent successfully",
  });
});

// Helper function to generate OTP for employee
const generateEmployeeOTP = async (employee) => {
  // Generate 6-digit OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  // Set OTP and expiry time in employee document
  employee.mobileVerificationOTP = otp;
  employee.mobileVerificationExpire = Date.now() + 10 * 60 * 1000; // 10 minutes

  await employee.save();

  return otp;
};

// @desc    Verify mobile OTP
// @route   POST /api/auth/verify-mobile-otp
// @access  Public
export const verifyMobileOTP = asyncHandler(async (req, res) => {
  const { mobile, otp } = req.body;

  // First check in User model
  const user = await User.findOne({
    mobile,
    mobileVerificationOTP: otp,
    mobileVerificationExpire: { $gt: Date.now() },
  }).populate("referredBy", "name referralCode");

  console.log("🚀 ~ verifyMobileOTP ~ user:", otp, mobile, user);

  // If found in User model
  if (user) {
    // Set mobile as verified
    user.isMobileVerified = true;
    user.mobileVerificationOTP = undefined;
    user.mobileVerificationExpire = undefined;
    await user.save();

    // Get referral info if user was referred
    let referralInfo = null;
    if (user.referredBy) {
      const referral = await Referral.findOne({
        referred: user._id,
        referrer: user.referredBy._id,
      });

      if (referral) {
        referralInfo = {
          referrerName: user.referredBy.name,
          referralCode: referral.referralCode,
          reward: referral.reward,
          status: referral.status,
        };
      }
    }

    // Generate token
    const token = generateToken(user._id);

    return res.status(200).json({
      success: true,
      message: "Mobile verified successfully",
      token,
      userType: user.role === "admin" ? "admin" : "user",
      data: {
        _id: user._id,
        name: user.name,
        email: user.email,
        mobile: user.mobile,
        isEmailVerified: user.isEmailVerified,
        isMobileVerified: user.isMobileVerified,
        walletBalance: user.walletBalance,
        referralCode: user.referralCode,
        role: user.role,
        referralInfo: referralInfo,
      },
    });
  }

  // Keep existing employee logic as is...
  const employee = await Employee.findOne({
    mobile,
    mobileVerificationOTP: otp,
    mobileVerificationExpire: { $gt: Date.now() },
  });

  if (employee) {
    employee.mobileVerificationOTP = undefined;
    employee.mobileVerificationExpire = undefined;
    await employee.save();

    const token = generateToken(employee._id);

    return res.status(200).json({
      success: true,
      message: "Mobile verified successfully",
      token,
      userType: "employee",
      data: {
        _id: employee._id,
        name: employee.name,
        email: employee.email,
        mobile: employee.mobile,
        role: employee.role,
        assignedModules: employee.assignedModules,
      },
    });
  }

  throw new ApiError("Invalid or expired OTP", 400);
});

// @desc    Login user with mobile OTP (works for users, admins, and employees)
// @route   POST /api/auth/login
// @access  Public
export const loginUser = asyncHandler(async (req, res) => {
  const { mobile, email, password } = req.body;

  // If mobile is provided, treat it as OTP-based login
  if (mobile) {
    // Check if user exists in User model
    const foundUser = await User.findOne({ mobile });
    let foundEmployee = null;
    let entityType = "user";

    if (!foundUser) {
      // If not found in User model, check Employee model
      foundEmployee = await Employee.findOne({ mobile });
      if (foundEmployee) {
        entityType = "employee";
      } else {
        throw new ApiError("User not found", 404);
      }
    }

    // Generate OTP for the found entity (user or employee)
    let otp;

    if (entityType === "user") {
      otp = foundUser.generateMobileVerificationOTP();
      await foundUser.save();
    } else {
      // If the entity is an employee, generate OTP for them
      otp = await generateEmployeeOTP(foundEmployee);
    }

    console.log("🚀 ~ loginUser ~ otp:", otp);

    const message = `
    <div style="max-width: 400px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; padding: 30px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
      <h2 style="margin: 0 0 20px; color: #333333; font-size: 20px;">Your Login Code</h2>
      
      <div style="background-color: #f5f5f5; border-radius: 6px; padding: 15px; margin: 20px 0;">
        <span style="font-family: monospace; font-size: 24px; font-weight: bold; letter-spacing: 4px; color: #333333;">${otp}</span>
      </div>
      
      <p style="margin: 0; color: #666666; font-size: 14px;">This code expires in 10 minutes.</p>
    </div>
  `;

  let userData = entityType === "user" ? foundUser : foundEmployee;
    
  console.log("📧 Email sending attempt:");
  console.log("Entity type:", entityType);
  console.log("User email:", userData.email);
  console.log("Email exists:", !!userData.email);

  if (!userData.email) {
    console.error("❌ No email found for", entityType);
    throw new ApiError(`No email address found for this ${entityType}`, 400);
  }

  try {
    console.log("📧 Sending email to:", userData.email);
    await sendEmail({
      email: userData.email,
      subject: "Email Verification",
      message,
    });
    console.log("✅ Email sent successfully to:", userData.email);
  } catch (emailError) {
    console.error("❌ Email sending failed:", emailError);
    throw new ApiError("Failed to send OTP email", 500);
  }

    console.log("🚀 ~ sendMobileOTP ~ otp:", otp);

    // Send OTP via SMS
    // await sendSMS({
    //   phone: mobile,
    //   message: `Your OTP for HappyGo login is: ${otp}. Valid for 10 minutes.`,
    // });

    return res.status(200).json({
      success: true,
      message: "OTP sent successfully",
    });
  }

  // If email and password are provided, check for employee login
  if (email && password) {
    // Check if it's a user (admin)
    const admin = await User.findOne({ email, role: "admin" });

    if (admin) {
      // For now, we don't have password auth for regular users/admins
      // Will need to add password field and validation to User model
      throw new ApiError(
        "Admin authentication with password not implemented yet",
        501
      );
    }

    // Check if it's an employee
    const employee = await Employee.findOne({ email }).select("+password");

    if (!employee) {
      throw new ApiError("Invalid credentials", 401);
    }

    // Check if employee is active
    if (!employee.isActive) {
      throw new ApiError(
        "Your account has been deactivated. Please contact admin.",
        401
      );
    }

    // Check if password matches
    const isMatch = await employee.matchPassword(password);

    if (!isMatch) {
      throw new ApiError("Invalid credentials", 401);
    }

    // Generate token
    const token = generateToken(employee._id);

    return res.status(200).json({
      success: true,
      token,
      userType: "employee",
      data: {
        _id: employee._id,
        name: employee.name,
        email: employee.email,
        mobile: employee.mobile,
        role: employee.role,
        assignedModules: employee.assignedModules,
      },
    });
  }

  // If neither mobile nor email/password provided
  throw new ApiError(
    "Please provide either mobile number for OTP or email/password for direct login",
    400
  );
});

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
export const getMe = asyncHandler(async (req, res) => {
  console.log("🚀 ~ getMe ~ req:", req?.user);
  const user = await User.findById(req?.user?.id);
  res.status(404).json({
    message: "user id not found",
  });

  res.status(200).json({
    success: true,
    data: {
      _id: user._id,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      isEmailVerified: user.isEmailVerified,
      isMobileVerified: user.isMobileVerified,
      walletBalance: user.walletBalance,
      referralCode: user.referralCode,
    },
  });
});
