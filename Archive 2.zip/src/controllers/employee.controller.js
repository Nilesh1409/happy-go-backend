import Employee from "../models/employee.model.js";
import Booking from "../models/booking.model.js";
import Order from "../models/order.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { generateToken } from "../utils/generateToken.js";
import bcrypt from "bcryptjs";

// @desc    Login employee
// @route   POST /api/employees/login
// @access  Public
export const loginEmployee = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // Validate email & password
  if (!email || !password) {
    throw new ApiError("Please provide email and password", 400);
  }

  // Check for employee
  const employee = await Employee.findOne({ email }).select("+password");

  if (!employee) {
    throw new ApiError("Invalid credentials", 401);
  }

  // Check if employee is active
  if (!employee.isActive) {
    throw new ApiError(
      "Your account has been deactivated. Please contact admin.",
      401
    );
  }

  // Check if password matches
  const isMatch = await employee.matchPassword(password);

  if (!isMatch) {
    throw new ApiError("Invalid credentials", 401);
  }

  // Generate token
  const token = generateToken(employee._id);

  res.status(200).json({
    success: true,
    token,
    data: {
      _id: employee._id,
      name: employee.name,
      email: employee.email,
      mobile: employee.mobile,
      role: employee.role,
      assignedModules: employee.assignedModules,
    },
  });
});

// @desc    Get current employee
// @route   GET /api/employees/me
// @access  Private/Employee
export const getMe = asyncHandler(async (req, res) => {
  const employee = await Employee.findById(req.employee._id);

  res.status(200).json({
    success: true,
    data: {
      _id: employee._id,
      name: employee.name,
      email: employee.email,
      mobile: employee.mobile,
      role: employee.role,
      assignedModules: employee.assignedModules,
      assignedEntities: employee.assignedEntities,
    },
  });
});

// @desc    Update employee password
// @route   PUT /api/employees/update-password
// @access  Private/Employee
export const updatePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  // Validate
  if (!currentPassword || !newPassword) {
    throw new ApiError("Please provide current and new password", 400);
  }

  // Get employee with password
  const employee = await Employee.findById(req.employee._id).select(
    "+password"
  );

  // Check current password
  const isMatch = await employee.matchPassword(currentPassword);
  if (!isMatch) {
    throw new ApiError("Current password is incorrect", 401);
  }

  // Update password
  const salt = await bcrypt.genSalt(10);
  employee.password = await bcrypt.hash(newPassword, salt);
  await employee.save();

  res.status(200).json({
    success: true,
    message: "Password updated successfully",
  });
});

// @desc    Get assigned bookings
// @route   GET /api/employees/bookings
// @access  Private/Employee
export const getAssignedBookings = asyncHandler(async (req, res) => {
  const { type, status, limit = 10, page = 1, sort } = req.query;

  // Build query
  const query = { assignedEmployee: req.employee._id };

  // Filter by type
  if (type) {
    query.bookingType = type;
  } else {
    // Filter by assigned modules
    query.bookingType = { $in: req.employee.assignedModules };
  }

  // Filter by status
  if (status) {
    query.bookingStatus = status;
  }

  // Filter by assigned entities if any
  if (req.employee.assignedEntities.length > 0) {
    const bikeIds = req.employee.assignedEntities.filter((id) =>
      req.employee.assignedModules.includes("bike")
    );

    const hotelIds = req.employee.assignedEntities.filter((id) =>
      req.employee.assignedModules.includes("hotel")
    );

    const entityQuery = [];

    if (bikeIds.length > 0) {
      entityQuery.push({ bike: { $in: bikeIds } });
    }

    if (hotelIds.length > 0) {
      entityQuery.push({ hotel: { $in: hotelIds } });
    }

    if (entityQuery.length > 0) {
      query.$or = entityQuery;
    }
  }

  // Count total documents
  const total = await Booking.countDocuments(query);

  // Build sort options
  let sortOptions = {};
  if (sort) {
    const sortFields = sort.split(",");
    sortFields.forEach((field) => {
      const sortOrder = field.startsWith("-") ? -1 : 1;
      const fieldName = field.startsWith("-") ? field.substring(1) : field;
      sortOptions[fieldName] = sortOrder;
    });
  } else {
    sortOptions = { createdAt: -1 };
  }

  // Pagination
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit);

  // Execute query
  const bookings = await Booking.find(query)
    .populate({
      path: "bike",
      select: "title brand model images",
    })
    .populate({
      path: "hotel",
      select: "name location images",
    })
    .populate({
      path: "user",
      select: "name email mobile",
    })
    .sort(sortOptions)
    .skip(skip)
    .limit(Number.parseInt(limit));

  res.status(200).json({
    success: true,
    count: bookings.length,
    total,
    page: Number.parseInt(page),
    pages: Math.ceil(total / Number.parseInt(limit)),
    data: bookings,
  });
});

// @desc    Get assigned orders
// @route   GET /api/employees/orders
// @access  Private/Employee
export const getAssignedOrders = asyncHandler(async (req, res) => {
  const { status, limit = 10, page = 1, sort } = req.query;

  // Build query
  const query = { assignedEmployee: req.employee._id };

  // Filter by status
  if (status) {
    query.orderStatus = status;
  }

  // Filter by assigned entities if any
  if (
    req.employee.assignedEntities.length > 0 &&
    req.employee.assignedModules.includes("product")
  ) {
    query["products.product"] = { $in: req.employee.assignedEntities };
  }

  // Count total documents
  const total = await Order.countDocuments(query);

  // Build sort options
  let sortOptions = {};
  if (sort) {
    const sortFields = sort.split(",");
    sortFields.forEach((field) => {
      const sortOrder = field.startsWith("-") ? -1 : 1;
      const fieldName = field.startsWith("-") ? field.substring(1) : field;
      sortOptions[fieldName] = sortOrder;
    });
  } else {
    sortOptions = { createdAt: -1 };
  }

  // Pagination
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit);

  // Execute query
  const orders = await Order.find(query)
    .populate({
      path: "products.product",
      select: "title images",
    })
    .populate({
      path: "user",
      select: "name email mobile",
    })
    .sort(sortOptions)
    .skip(skip)
    .limit(Number.parseInt(limit));

  res.status(200).json({
    success: true,
    count: orders.length,
    total,
    page: Number.parseInt(page),
    pages: Math.ceil(total / Number.parseInt(limit)),
    data: orders,
  });
});

// @desc    Update booking status by employee
// @route   PUT /api/employees/bookings/:id/status
// @access  Private/Employee
export const updateBookingStatus = asyncHandler(async (req, res) => {
  const { status, initialKmReading, finalKmReading, additionalCharges } =
    req.body;

  // Validate status
  if (!status || !["confirmed", "cancelled", "completed"].includes(status)) {
    throw new ApiError("Invalid status", 400);
  }

  // Get booking
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    throw new ApiError("Booking not found", 404);
  }

  // Check if booking is assigned to employee
  if (booking.assignedEmployee?.toString() !== req.employee._id.toString()) {
    throw new ApiError("Not authorized to update this booking", 401);
  }

  // Update booking
  booking.bookingStatus = status;

  // For bike bookings, update additional details
  if (booking.bookingType === "bike") {
    if (status === "confirmed" && initialKmReading) {
      booking.bikeDetails.initialKmReading = initialKmReading;
    }

    if (status === "completed") {
      if (!finalKmReading) {
        throw new ApiError("Please provide final km reading", 400);
      }

      booking.bikeDetails.finalKmReading = finalKmReading;

      // Calculate additional charges if any
      if (additionalCharges) {
        booking.bikeDetails.additionalCharges = additionalCharges;
      }
    }
  }

  await booking.save();

  res.status(200).json({
    success: true,
    data: booking,
  });
});

// @desc    Update order status by employee
// @route   PUT /api/employees/orders/:id/status
// @access  Private/Employee
export const updateOrderStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;

  // Validate status
  if (
    !status ||
    !["processing", "shipped", "delivered", "cancelled"].includes(status)
  ) {
    throw new ApiError("Invalid status", 400);
  }

  // Get order
  const order = await Order.findById(req.params.id);

  if (!order) {
    throw new ApiError("Order not found", 404);
  }

  // Check if order is assigned to employee
  if (order.assignedEmployee?.toString() !== req.employee._id.toString()) {
    throw new ApiError("Not authorized to update this order", 401);
  }

  // Update order
  order.orderStatus = status;
  await order.save();

  res.status(200).json({
    success: true,
    data: order,
  });
});

// @desc    Get employee dashboard data
// @route   GET /api/employees/dashboard
// @access  Private/Employee
export const getDashboardData = asyncHandler(async (req, res) => {
  console.log("🚀 ~ in getDashboardData ~ getDashboardData:");
  // Get assigned bookings count
  const bikeBookingsCount = await Booking.countDocuments({
    assignedEmployee: req.employee._id,
    bookingType: "bike",
  });

  const hotelBookingsCount = await Booking.countDocuments({
    assignedEmployee: req.employee._id,
    bookingType: "hotel",
  });

  const ordersCount = await Order.countDocuments({
    assignedEmployee: req.employee._id,
  });

  // Get pending actions
  const pendingBikeBookings = await Booking.countDocuments({
    assignedEmployee: req.employee._id,
    bookingType: "bike",
    bookingStatus: "pending",
  });

  const pendingHotelBookings = await Booking.countDocuments({
    assignedEmployee: req.employee._id,
    bookingType: "hotel",
    bookingStatus: "pending",
  });

  const pendingOrders = await Order.countDocuments({
    assignedEmployee: req.employee._id,
    orderStatus: "pending",
  });

  // Get recent bookings/orders
  const recentBikeBookings = await Booking.find({
    assignedEmployee: req.employee._id,
    bookingType: "bike",
  })
    .populate({
      path: "bike",
      select: "title brand model images",
    })
    .populate({
      path: "user",
      select: "name mobile",
    })
    .sort({ createdAt: -1 })
    .limit(5);

  const recentHotelBookings = await Booking.find({
    assignedEmployee: req.employee._id,
    bookingType: "hotel",
  })
    .populate({
      path: "hotel",
      select: "name location images",
    })
    .populate({
      path: "user",
      select: "name mobile",
    })
    .sort({ createdAt: -1 })
    .limit(5);

  const recentOrders = await Order.find({
    assignedEmployee: req.employee._id,
  })
    .populate({
      path: "products.product",
      select: "title images",
    })
    .populate({
      path: "user",
      select: "name mobile",
    })
    .sort({ createdAt: -1 })
    .limit(5);

  res.status(200).json({
    success: true,
    data: {
      counts: {
        bikeBookings: bikeBookingsCount,
        hotelBookings: hotelBookingsCount,
        orders: ordersCount,
        total: bikeBookingsCount + hotelBookingsCount + ordersCount,
      },
      pendingActions: {
        bikeBookings: pendingBikeBookings,
        hotelBookings: pendingHotelBookings,
        orders: pendingOrders,
        total: pendingBikeBookings + pendingHotelBookings + pendingOrders,
      },
      recent: {
        bikeBookings: recentBikeBookings,
        hotelBookings: recentHotelBookings,
        orders: recentOrders,
      },
    },
  });
});
