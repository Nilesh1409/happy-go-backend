import express from "express";
import {
  createBooking,
  getBookings,
  getBooking,
  updateBookingStatus,
  uploadDocuments,
  calculateAdditionalCharges,
  getHotelBookings,
  getBikeBookings,
  updateHotelBookingDetails,
  getBookingStats,
  extendBikeBooking,
  completeBikeBooking,
} from "../controllers/booking.controller.js";
import {
  protect,
  adminProtect,
  employeeProtect,
} from "../middleware/auth.middleware.js";

const router = express.Router();

// User routes
router.post("/", protect, createBooking);
router.get("/", protect, getBookings);
router.get("/hotels", protect, getHotelBookings);
router.get("/bikes", protect, getBikeBookings);
router.get("/:id", protect, getBooking);
router.put("/:id/status", protect, updateBookingStatus);
router.put("/:id/documents", protect, uploadDocuments);
router.put("/:id/hotel-details", protect, updateHotelBookingDetails);

// Employee routes
router.put(
  "/:id/additional-charges",
  employeeProtect,
  calculateAdditionalCharges
);
router.put("/:id/extend", employeeProtect, extendBikeBooking);
router.put("/:id/complete", employeeProtect, completeBikeBooking);

// Admin routes
router.get("/stats", adminProtect, getBookingStats);

export default router;
